TBE INSTALL FAQ FOR DUMMIES. 


In Xilinx License Configuration Manager go to "Manage Xilinx Licenses"

Press "Copy License..."

Use "xilinx_ise.lic" from Crack Dir.

That's it, folks.